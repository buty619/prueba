import React from 'react'
import styles from '../styles/Home.module.css'

const Filter = ({name, isChecked, onChecked, children, search}) => {

    const [inputValue, setInputValue] = React.useState('');
    const handleOnChange = (e) => {
        setInputValue(e.target.value)
    }

    return (
        <div>
            <label>
                <input type="radio" name={name} checked={isChecked} onChange={onChecked}/>
                {children}
            </label>
            {name === 'category' ? 
                <select value={inputValue} onChange={handleOnChange}>
                    <option value="Category1">Category1</option>
                    <option value="Category2">Category2</option>
                    <option value="Category3">Category3</option>
                    <option value="Category4">Category4</option>
                </select>: 
                <input type="text" onChange={handleOnChange} value={inputValue}/>}
            <button onClick={() => search(inputValue, isChecked)}>Buscar</button>
        </div>
    )
}

export default Filter