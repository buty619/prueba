import React from 'react'
import styles from '../styles/Home.module.css'
import Context from '../state/context'

const DeleteBtn = ({productId}) => {

    const {deleteProducts} = React.useContext(Context);

    const handleDelete = (productId) => {
        deleteProducts(productId)
    }

    return (
        <button onClick={() => handleDelete(productId)}>Delete</button>
    )
}

export default DeleteBtn