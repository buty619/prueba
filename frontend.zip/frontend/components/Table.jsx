import React from 'react'
import styles from '../styles/Home.module.css'
import DeleteBtn from './DeleteBtn'

const Table = ({data}) => {
    return (
        <table className={styles.table}>
            <thead>
                <tr>
                    <th>Eliminar</th>
                    <th>Nombre</th>
                    <th>Categoria</th>
                    <th>Disponible</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Image</th>
                </tr>
            </thead>
            <tbody>
                {data.map(row => (
                    <tr key={row.id} id={row.id}>
                        <td><DeleteBtn productId={row.id} /></td>
                        <td>{row.productName}</td>
                        <td>{row.Category}</td>
                        <td>{row.Available ? 'si' : 'no'}</td>
                        <td>{row.Price}</td>
                        <td>{row.Stock}</td>
                        <td>{row.Image}</td>
                    </tr>
                ))}
                
            </tbody>
        </table>
    )
}

export default Table