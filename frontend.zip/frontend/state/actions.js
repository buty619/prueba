const LOAD_PRODUCTS = "LOAD_PRODUCTS";
const DELETE_PRODUCTS = "DELETE_PRODUCTS";
const CREATE_PRODUCTS = "CREATE_PRODUCTS";

// eslint-disable-next-line import/no-anonymous-default-export
export default { LOAD_PRODUCTS, DELETE_PRODUCTS, CREATE_PRODUCTS };
