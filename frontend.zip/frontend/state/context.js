import React from "react";

export const initialState = {
  products: [],
};

const context = React.createContext(initialState);

export default context;