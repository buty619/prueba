import actions from "./actions";

// eslint-disable-next-line import/no-anonymous-default-export
export default (state, action) => {
  switch (action.type) {
    case actions.LOAD_PRODUCTS: {
        return { ... state, products: action.jsonFetch};
    }
    case actions.DELETE_PRODUCTS: {
        return { ... state, products: action.jsonFetch };
    }
    case actions.CREATE_PRODUCTS: {
        return { ... state, products: action.jsonFetch };
    }
    default:
      return {};
  }
};