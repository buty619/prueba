import React from "react";
import Context, { initialState } from "./context";
import actions from "./actions";
import reducer from "./reducer";

const fetchSwa = async (url, fetchOptions = {}, setFunction) => {
    try {
      const fetchData = await fetch(url, fetchOptions);
      const jsonFetch = await fetchData.json();
      setFunction(jsonFetch);
    } catch (e) {
      console.error("FETCH ERROR", e);
    }
  };

const GlobalState = ({ children }) => {
  const [state, dispatch] = React.useReducer(reducer, initialState);

  const loadProducts = () => fetchSwa("http://localhost:8080", {}, (jsonFetch) => dispatch({ type: actions.LOAD_PRODUCTS, jsonFetch }));
  const deleteProducts = (id) => fetchSwa("http://localhost:8080/delete/"+id, { method: 'DELETE' }, (jsonFetch) => dispatch({ type: actions.DELETE_PRODUCTS, jsonFetch }));
  const createProducts = (product) => fetchSwa("http://localhost:8080/create", { method: 'POST', body: JSON.stringify(product), headers: { 
    'Accept': 'application/json',
    'Content-Type': 'application/json' 
} }, (jsonFetch) => dispatch({ type: actions.CREATE_PRODUCTS, jsonFetch }));

  return (
    <Context.Provider
      value={{
        ...state,
        loadProducts,
        deleteProducts,
        createProducts
      }}
    >
      {children}
    </Context.Provider>
  );
};

export default GlobalState;
