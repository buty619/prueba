import React from 'react'
import styles from '../styles/Home.module.css'
import Table from '../components/Table'
import Filter from '../components/Filter'
import Context from '../state/context';

const ListOfProducts = () => {

    const {products, loadProducts} = React.useContext(Context);
    const [productsFilter, setProductsFilter] = React.useState(null);
    const [checkbox, setCheckbox] = React.useState('lestPrice');

    React.useEffect(() => {
        loadProducts();
    }, []);

    React.useEffect(() => {
        setProductsFilter(products);
    }, [products]);

    const handleCheckbox = (e) => {
        setCheckbox(e.target.name);
    }

    const handleSearch = (value, isChecked) => {
        if(isChecked){
            switch (checkbox) {
                case 'lestPrice':
                    setProductsFilter(products.filter(({Price})=> Price < value))
                  break;
                case 'name':
                    setProductsFilter(products.filter(({productName})=> productName.toLowerCase().includes(value.toLowerCase())))
                  break;
                case 'category':
                    setProductsFilter(products.filter(({Category})=> Category === value))
                  break;
                default:
                    setProductsFilter(products)
            }
        }
    }

    const handleReset = () => {
        setProductsFilter(products);
    }

    return (
        <div className={styles.main}>
            <h1 className={styles.title}>
            Comercializadora "a tiro de as"
            </h1>
            <h1>
            Catalogo de Productos
            </h1>


            <div className={styles.grid}>
                <a href="/" className={styles.card}>
                    <h2>Regresar&rarr;</h2>
                </a>
            </div>

            <Filter name="lestPrice" isChecked={checkbox === 'lestPrice'} onChecked={handleCheckbox} search={(value, isChecked) => handleSearch(value, isChecked)}>
                Consulta por menor precio
            </Filter>
            <Filter name="name" isChecked={checkbox === 'name'} onChecked={handleCheckbox} search={(value, isChecked) => handleSearch(value, isChecked)}>
                Consulta por nombre
            </Filter>
            <Filter name="category" isChecked={checkbox === 'category'} onChecked={handleCheckbox} search={(value, isChecked) => handleSearch(value, isChecked)}>
                Consulta por categoria
            </Filter>

            <Table data={productsFilter || products} />
            <button onClick={handleReset}>Reset Filters</button>
        </div>
    )
}

export default ListOfProducts