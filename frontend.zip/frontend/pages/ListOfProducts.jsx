import React from 'react'
import styles from '../styles/Home.module.css'
import Table from '../components/Table'
import Context from '../state/context';

const ListOfProducts = () => {

    const {products, loadProducts} = React.useContext(Context);

    React.useEffect(() => {
        loadProducts();
    }, []);

    return (
        <div className={styles.main}>
            <h1 className={styles.title}>
            Comercializadora "a tiro de as"
            </h1>
            <h1>
            Listado de Productos
            </h1>


            <div className={styles.grid}>
            <a href="/" className={styles.card}>
                <h2>Regresar&rarr;</h2>
            </a>
            </div>
            <Table data={products} />
        </div>
    )
}

export default ListOfProducts