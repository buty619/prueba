import React from 'react'
import styles from '../styles/Home.module.css'
import Context from '../state/context';
import Router from 'next/router'

const Create = ({id}) => {

    const {createProducts} = React.useContext(Context);
    const [inputValue, setInputValue] = React.useState({})

    const handleOnChange = (e) => {
        setInputValue({...inputValue, [e.target.name]:e.target.value})
    }

    const handleSave = ()  => {
        createProducts(inputValue)
        Router.push('/')
    }


    return (
        <div className={styles.main}>
            <h1 className={styles.title}>
                Crear Producto
            </h1>
            <table className={styles.table}>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Categoria</th>
                    <th>Disponible (true/false)</th>
                    <th>Precio(Numero)</th>
                    <th>Stock(Numero)</th>
                    <th>Imagen(string)</th>
                </tr>
            </thead>
            <tbody>
                <tr id={id}>
                    <td><input type="text" onChange={handleOnChange} value={inputValue.productName} name="productName"/></td>
                    <td><input type="text" onChange={handleOnChange} value={inputValue.Category} name="Category"/></td>
                    <td><input type="text" onChange={handleOnChange} value={inputValue.Available} name="Available"/></td>
                    <td><input type="text" onChange={handleOnChange} value={inputValue.Price} name="Price"/></td>
                    <td><input type="text" onChange={handleOnChange} value={inputValue.Stock} name="Stock"/></td>
                    <td><input type="text" onChange={handleOnChange} value={inputValue.Image} name="Image"/></td>
                </tr>
            </tbody>
        </table>
        <button onClick={handleSave}>Guardar</button>
        </div>
    )
}

export default Create