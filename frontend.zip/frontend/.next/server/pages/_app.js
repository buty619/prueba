/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"react/jsx-runtime\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _state_GlobalContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../state/GlobalContext */ \"./state/GlobalContext.js\");\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_state_GlobalContext__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        __source: {\n            fileName: \"/Users/cristian/Documents/projects/frontend/pages/_app.js\",\n            lineNumber: 5,\n            columnNumber: 10\n        },\n        __self: this,\n        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(Component, {\n            ...pageProps,\n            __source: {\n                fileName: \"/Users/cristian/Documents/projects/frontend/pages/_app.js\",\n                lineNumber: 5,\n                columnNumber: 23\n            },\n            __self: this\n        })\n    }));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBOEI7QUFDbUI7U0FFeENDLEtBQUssQ0FBQyxDQUFDLENBQUNDLFNBQVMsR0FBRUMsU0FBUyxFQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3hDLE1BQU0sc0VBQUVILDREQUFXOzs7Ozs7O3VGQUFFRSxTQUFTO2VBQUtDLFNBQVM7Ozs7Ozs7OztBQUM5QyxDQUFDO0FBRUQsaUVBQWVGLEtBQUsiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udGVuZC8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uL3N0eWxlcy9nbG9iYWxzLmNzcydcbmltcG9ydCBHbG9iYWxTdGF0ZSAgZnJvbSAnLi4vc3RhdGUvR2xvYmFsQ29udGV4dCdcblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XG4gIHJldHVybiA8R2xvYmFsU3RhdGU+PENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPjwvR2xvYmFsU3RhdGU+XG59XG5cbmV4cG9ydCBkZWZhdWx0IE15QXBwXG4iXSwibmFtZXMiOlsiR2xvYmFsU3RhdGUiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./state/GlobalContext.js":
/*!********************************!*\
  !*** ./state/GlobalContext.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ \"react/jsx-runtime\");\n/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./context */ \"./state/context.js\");\n/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./actions */ \"./state/actions.js\");\n/* harmony import */ var _reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./reducer */ \"./state/reducer.js\");\n\n\n\n\n\nconst fetchSwa = async (url, fetchOptions = {\n}, setFunction)=>{\n    try {\n        const fetchData = await fetch(url, fetchOptions);\n        const jsonFetch = await fetchData.json();\n        setFunction(jsonFetch);\n    } catch (e) {\n        console.error(\"FETCH ERROR\", e);\n    }\n};\nconst GlobalState = ({ children  })=>{\n    const [state, dispatch] = react__WEBPACK_IMPORTED_MODULE_1___default().useReducer(_reducer__WEBPACK_IMPORTED_MODULE_4__[\"default\"], _context__WEBPACK_IMPORTED_MODULE_2__.initialState);\n    const loadProducts = ()=>fetchSwa(\"http://localhost:8080\", {\n        }, (jsonFetch)=>dispatch({\n                type: _actions__WEBPACK_IMPORTED_MODULE_3__[\"default\"].LOAD_PRODUCTS,\n                jsonFetch\n            })\n        )\n    ;\n    const deleteProducts = (id)=>fetchSwa(\"http://localhost:8080/delete/\" + id, {\n            method: 'DELETE'\n        }, (jsonFetch)=>dispatch({\n                type: _actions__WEBPACK_IMPORTED_MODULE_3__[\"default\"].DELETE_PRODUCTS,\n                jsonFetch\n            })\n        )\n    ;\n    const createProducts = (product)=>fetchSwa(\"http://localhost:8080/create\", {\n            method: 'POST',\n            body: JSON.stringify(product),\n            headers: {\n                'Accept': 'application/json',\n                'Content-Type': 'application/json'\n            }\n        }, (jsonFetch)=>dispatch({\n                type: _actions__WEBPACK_IMPORTED_MODULE_3__[\"default\"].CREATE_PRODUCTS,\n                jsonFetch\n            })\n        )\n    ;\n    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_context__WEBPACK_IMPORTED_MODULE_2__[\"default\"].Provider, {\n        value: {\n            ...state,\n            loadProducts,\n            deleteProducts,\n            createProducts\n        },\n        __source: {\n            fileName: \"/Users/cristian/Documents/projects/frontend/state/GlobalContext.js\",\n            lineNumber: 27,\n            columnNumber: 5\n        },\n        __self: undefined,\n        children: children\n    }));\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GlobalState);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdGF0ZS9HbG9iYWxDb250ZXh0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUF5QjtBQUN3QjtBQUNsQjtBQUNBO0FBRS9CLEtBQUssQ0FBQ0ssUUFBUSxVQUFVQyxHQUFHLEVBQUVDLFlBQVksR0FBRyxDQUFDO0FBQUEsQ0FBQyxFQUFFQyxXQUFXLEdBQUssQ0FBQztJQUM3RCxHQUFHLENBQUMsQ0FBQztRQUNILEtBQUssQ0FBQ0MsU0FBUyxHQUFHLEtBQUssQ0FBQ0MsS0FBSyxDQUFDSixHQUFHLEVBQUVDLFlBQVk7UUFDL0MsS0FBSyxDQUFDSSxTQUFTLEdBQUcsS0FBSyxDQUFDRixTQUFTLENBQUNHLElBQUk7UUFDdENKLFdBQVcsQ0FBQ0csU0FBUztJQUN2QixDQUFDLENBQUMsS0FBSyxFQUFFRSxDQUFDLEVBQUUsQ0FBQztRQUNYQyxPQUFPLENBQUNDLEtBQUssQ0FBQyxDQUFhLGNBQUVGLENBQUM7SUFDaEMsQ0FBQztBQUNILENBQUM7QUFFSCxLQUFLLENBQUNHLFdBQVcsSUFBSSxDQUFDLENBQUNDLFFBQVEsRUFBQyxDQUFDLEdBQUssQ0FBQztJQUNyQyxLQUFLLEVBQUVDLEtBQUssRUFBRUMsUUFBUSxJQUFJbkIsdURBQWdCLENBQUNJLGdEQUFPLEVBQUVGLGtEQUFZO0lBRWhFLEtBQUssQ0FBQ21CLFlBQVksT0FBU2hCLFFBQVEsQ0FBQyxDQUF1Qix3QkFBRSxDQUFDO1FBQUEsQ0FBQyxHQUFHTSxTQUFTLEdBQUtRLFFBQVEsQ0FBQyxDQUFDO2dCQUFDRyxJQUFJLEVBQUVuQiw4REFBcUI7Z0JBQUVRLFNBQVM7WUFBQyxDQUFDOzs7SUFDbkksS0FBSyxDQUFDYSxjQUFjLElBQUlDLEVBQUUsR0FBS3BCLFFBQVEsQ0FBQyxDQUErQixpQ0FBQ29CLEVBQUUsRUFBRSxDQUFDO1lBQUNDLE1BQU0sRUFBRSxDQUFRO1FBQUMsQ0FBQyxHQUFHZixTQUFTLEdBQUtRLFFBQVEsQ0FBQyxDQUFDO2dCQUFDRyxJQUFJLEVBQUVuQixnRUFBdUI7Z0JBQUVRLFNBQVM7WUFBQyxDQUFDOzs7SUFDdEssS0FBSyxDQUFDaUIsY0FBYyxJQUFJQyxPQUFPLEdBQUt4QixRQUFRLENBQUMsQ0FBOEIsK0JBQUUsQ0FBQztZQUFDcUIsTUFBTSxFQUFFLENBQU07WUFBRUksSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQ0gsT0FBTztZQUFHSSxPQUFPLEVBQUUsQ0FBQztnQkFDdEksQ0FBUSxTQUFFLENBQWtCO2dCQUM1QixDQUFjLGVBQUUsQ0FBa0I7WUFDdEMsQ0FBQztRQUFDLENBQUMsR0FBR3RCLFNBQVMsR0FBS1EsUUFBUSxDQUFDLENBQUM7Z0JBQUNHLElBQUksRUFBRW5CLGdFQUF1QjtnQkFBRVEsU0FBUztZQUFDLENBQUM7OztJQUV2RSxNQUFNLHNFQUNIVix5REFBZ0I7UUFDZm1DLEtBQUssRUFBRSxDQUFDO2VBQ0hsQixLQUFLO1lBQ1JHLFlBQVk7WUFDWkcsY0FBYztZQUNkSSxjQUFjO1FBQ2hCLENBQUM7Ozs7Ozs7a0JBRUFYLFFBQVE7O0FBR2YsQ0FBQztBQUVELGlFQUFlRCxXQUFXLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udGVuZC8uL3N0YXRlL0dsb2JhbENvbnRleHQuanM/OGZhYSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgQ29udGV4dCwgeyBpbml0aWFsU3RhdGUgfSBmcm9tIFwiLi9jb250ZXh0XCI7XG5pbXBvcnQgYWN0aW9ucyBmcm9tIFwiLi9hY3Rpb25zXCI7XG5pbXBvcnQgcmVkdWNlciBmcm9tIFwiLi9yZWR1Y2VyXCI7XG5cbmNvbnN0IGZldGNoU3dhID0gYXN5bmMgKHVybCwgZmV0Y2hPcHRpb25zID0ge30sIHNldEZ1bmN0aW9uKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZldGNoRGF0YSA9IGF3YWl0IGZldGNoKHVybCwgZmV0Y2hPcHRpb25zKTtcbiAgICAgIGNvbnN0IGpzb25GZXRjaCA9IGF3YWl0IGZldGNoRGF0YS5qc29uKCk7XG4gICAgICBzZXRGdW5jdGlvbihqc29uRmV0Y2gpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGRVRDSCBFUlJPUlwiLCBlKTtcbiAgICB9XG4gIH07XG5cbmNvbnN0IEdsb2JhbFN0YXRlID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuICBjb25zdCBbc3RhdGUsIGRpc3BhdGNoXSA9IFJlYWN0LnVzZVJlZHVjZXIocmVkdWNlciwgaW5pdGlhbFN0YXRlKTtcblxuICBjb25zdCBsb2FkUHJvZHVjdHMgPSAoKSA9PiBmZXRjaFN3YShcImh0dHA6Ly9sb2NhbGhvc3Q6ODA4MFwiLCB7fSwgKGpzb25GZXRjaCkgPT4gZGlzcGF0Y2goeyB0eXBlOiBhY3Rpb25zLkxPQURfUFJPRFVDVFMsIGpzb25GZXRjaCB9KSk7XG4gIGNvbnN0IGRlbGV0ZVByb2R1Y3RzID0gKGlkKSA9PiBmZXRjaFN3YShcImh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9kZWxldGUvXCIraWQsIHsgbWV0aG9kOiAnREVMRVRFJyB9LCAoanNvbkZldGNoKSA9PiBkaXNwYXRjaCh7IHR5cGU6IGFjdGlvbnMuREVMRVRFX1BST0RVQ1RTLCBqc29uRmV0Y2ggfSkpO1xuICBjb25zdCBjcmVhdGVQcm9kdWN0cyA9IChwcm9kdWN0KSA9PiBmZXRjaFN3YShcImh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9jcmVhdGVcIiwgeyBtZXRob2Q6ICdQT1NUJywgYm9keTogSlNPTi5zdHJpbmdpZnkocHJvZHVjdCksIGhlYWRlcnM6IHsgXG4gICAgJ0FjY2VwdCc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIFxufSB9LCAoanNvbkZldGNoKSA9PiBkaXNwYXRjaCh7IHR5cGU6IGFjdGlvbnMuQ1JFQVRFX1BST0RVQ1RTLCBqc29uRmV0Y2ggfSkpO1xuXG4gIHJldHVybiAoXG4gICAgPENvbnRleHQuUHJvdmlkZXJcbiAgICAgIHZhbHVlPXt7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICBsb2FkUHJvZHVjdHMsXG4gICAgICAgIGRlbGV0ZVByb2R1Y3RzLFxuICAgICAgICBjcmVhdGVQcm9kdWN0c1xuICAgICAgfX1cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9Db250ZXh0LlByb3ZpZGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgR2xvYmFsU3RhdGU7XG4iXSwibmFtZXMiOlsiUmVhY3QiLCJDb250ZXh0IiwiaW5pdGlhbFN0YXRlIiwiYWN0aW9ucyIsInJlZHVjZXIiLCJmZXRjaFN3YSIsInVybCIsImZldGNoT3B0aW9ucyIsInNldEZ1bmN0aW9uIiwiZmV0Y2hEYXRhIiwiZmV0Y2giLCJqc29uRmV0Y2giLCJqc29uIiwiZSIsImNvbnNvbGUiLCJlcnJvciIsIkdsb2JhbFN0YXRlIiwiY2hpbGRyZW4iLCJzdGF0ZSIsImRpc3BhdGNoIiwidXNlUmVkdWNlciIsImxvYWRQcm9kdWN0cyIsInR5cGUiLCJMT0FEX1BST0RVQ1RTIiwiZGVsZXRlUHJvZHVjdHMiLCJpZCIsIm1ldGhvZCIsIkRFTEVURV9QUk9EVUNUUyIsImNyZWF0ZVByb2R1Y3RzIiwicHJvZHVjdCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwiaGVhZGVycyIsIkNSRUFURV9QUk9EVUNUUyIsIlByb3ZpZGVyIiwidmFsdWUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./state/GlobalContext.js\n");

/***/ }),

/***/ "./state/actions.js":
/*!**************************!*\
  !*** ./state/actions.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nconst LOAD_PRODUCTS = \"LOAD_PRODUCTS\";\nconst DELETE_PRODUCTS = \"DELETE_PRODUCTS\";\nconst CREATE_PRODUCTS = \"CREATE_PRODUCTS\";\n// eslint-disable-next-line import/no-anonymous-default-export\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\n    LOAD_PRODUCTS,\n    DELETE_PRODUCTS,\n    CREATE_PRODUCTS\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdGF0ZS9hY3Rpb25zLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxLQUFLLENBQUNBLGFBQWEsR0FBRyxDQUFlO0FBQ3JDLEtBQUssQ0FBQ0MsZUFBZSxHQUFHLENBQWlCO0FBQ3pDLEtBQUssQ0FBQ0MsZUFBZSxHQUFHLENBQWlCO0FBRXpDLEVBQThEO0FBQzlELGlFQUFlLENBQUM7SUFBQ0YsYUFBYTtJQUFFQyxlQUFlO0lBQUVDLGVBQWU7QUFBQyxDQUFDLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udGVuZC8uL3N0YXRlL2FjdGlvbnMuanM/YTVhMSJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBMT0FEX1BST0RVQ1RTID0gXCJMT0FEX1BST0RVQ1RTXCI7XG5jb25zdCBERUxFVEVfUFJPRFVDVFMgPSBcIkRFTEVURV9QUk9EVUNUU1wiO1xuY29uc3QgQ1JFQVRFX1BST0RVQ1RTID0gXCJDUkVBVEVfUFJPRFVDVFNcIjtcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9uby1hbm9ueW1vdXMtZGVmYXVsdC1leHBvcnRcbmV4cG9ydCBkZWZhdWx0IHsgTE9BRF9QUk9EVUNUUywgREVMRVRFX1BST0RVQ1RTLCBDUkVBVEVfUFJPRFVDVFMgfTtcbiJdLCJuYW1lcyI6WyJMT0FEX1BST0RVQ1RTIiwiREVMRVRFX1BST0RVQ1RTIiwiQ1JFQVRFX1BST0RVQ1RTIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./state/actions.js\n");

/***/ }),

/***/ "./state/context.js":
/*!**************************!*\
  !*** ./state/context.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"initialState\": () => (/* binding */ initialState),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\nconst initialState = {\n    products: []\n};\nconst context = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().createContext(initialState);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (context);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdGF0ZS9jb250ZXh0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBeUI7QUFFbEIsS0FBSyxDQUFDQyxZQUFZLEdBQUcsQ0FBQztJQUMzQkMsUUFBUSxFQUFFLENBQUMsQ0FBQztBQUNkLENBQUM7QUFFRCxLQUFLLENBQUNDLE9BQU8saUJBQUdILDBEQUFtQixDQUFDQyxZQUFZO0FBRWhELGlFQUFlRSxPQUFPLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udGVuZC8uL3N0YXRlL2NvbnRleHQuanM/ZGIwMSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBjb25zdCBpbml0aWFsU3RhdGUgPSB7XG4gIHByb2R1Y3RzOiBbXSxcbn07XG5cbmNvbnN0IGNvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KGluaXRpYWxTdGF0ZSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbnRleHQ7Il0sIm5hbWVzIjpbIlJlYWN0IiwiaW5pdGlhbFN0YXRlIiwicHJvZHVjdHMiLCJjb250ZXh0IiwiY3JlYXRlQ29udGV4dCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./state/context.js\n");

/***/ }),

/***/ "./state/reducer.js":
/*!**************************!*\
  !*** ./state/reducer.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./actions */ \"./state/actions.js\");\n\n// eslint-disable-next-line import/no-anonymous-default-export\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((state, action)=>{\n    switch(action.type){\n        case _actions__WEBPACK_IMPORTED_MODULE_0__[\"default\"].LOAD_PRODUCTS:\n            {\n                return {\n                    ...state,\n                    products: action.jsonFetch\n                };\n            }\n        case _actions__WEBPACK_IMPORTED_MODULE_0__[\"default\"].DELETE_PRODUCTS:\n            {\n                return {\n                    ...state,\n                    products: action.jsonFetch\n                };\n            }\n        case _actions__WEBPACK_IMPORTED_MODULE_0__[\"default\"].CREATE_PRODUCTS:\n            {\n                return {\n                    ...state,\n                    products: action.jsonFetch\n                };\n            }\n        default:\n            return {\n            };\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdGF0ZS9yZWR1Y2VyLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQStCO0FBRS9CLEVBQThEO0FBQzlELGlFQUFnQixDQUFBQyxLQUFLLEVBQUVDLE1BQU0sR0FBSyxDQUFDO0lBQ2pDLE1BQU0sQ0FBRUEsTUFBTSxDQUFDQyxJQUFJO1FBQ2pCLElBQUksQ0FBQ0gsOERBQXFCO1lBQUUsQ0FBQztnQkFDekIsTUFBTSxDQUFDLENBQUM7dUJBQUtDLEtBQUs7b0JBQUVJLFFBQVEsRUFBRUgsTUFBTSxDQUFDSSxTQUFTO2dCQUFBLENBQUM7WUFDbkQsQ0FBQztRQUNELElBQUksQ0FBQ04sZ0VBQXVCO1lBQUUsQ0FBQztnQkFDM0IsTUFBTSxDQUFDLENBQUM7dUJBQUtDLEtBQUs7b0JBQUVJLFFBQVEsRUFBRUgsTUFBTSxDQUFDSSxTQUFTO2dCQUFDLENBQUM7WUFDcEQsQ0FBQztRQUNELElBQUksQ0FBQ04sZ0VBQXVCO1lBQUUsQ0FBQztnQkFDM0IsTUFBTSxDQUFDLENBQUM7dUJBQUtDLEtBQUs7b0JBQUVJLFFBQVEsRUFBRUgsTUFBTSxDQUFDSSxTQUFTO2dCQUFDLENBQUM7WUFDcEQsQ0FBQzs7WUFFQyxNQUFNLENBQUMsQ0FBQztZQUFBLENBQUM7O0FBRWYsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250ZW5kLy4vc3RhdGUvcmVkdWNlci5qcz81NTNjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBhY3Rpb25zIGZyb20gXCIuL2FjdGlvbnNcIjtcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9uby1hbm9ueW1vdXMtZGVmYXVsdC1leHBvcnRcbmV4cG9ydCBkZWZhdWx0IChzdGF0ZSwgYWN0aW9uKSA9PiB7XG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcbiAgICBjYXNlIGFjdGlvbnMuTE9BRF9QUk9EVUNUUzoge1xuICAgICAgICByZXR1cm4geyAuLi4gc3RhdGUsIHByb2R1Y3RzOiBhY3Rpb24uanNvbkZldGNofTtcbiAgICB9XG4gICAgY2FzZSBhY3Rpb25zLkRFTEVURV9QUk9EVUNUUzoge1xuICAgICAgICByZXR1cm4geyAuLi4gc3RhdGUsIHByb2R1Y3RzOiBhY3Rpb24uanNvbkZldGNoIH07XG4gICAgfVxuICAgIGNhc2UgYWN0aW9ucy5DUkVBVEVfUFJPRFVDVFM6IHtcbiAgICAgICAgcmV0dXJuIHsgLi4uIHN0YXRlLCBwcm9kdWN0czogYWN0aW9uLmpzb25GZXRjaCB9O1xuICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHt9O1xuICB9XG59OyJdLCJuYW1lcyI6WyJhY3Rpb25zIiwic3RhdGUiLCJhY3Rpb24iLCJ0eXBlIiwiTE9BRF9QUk9EVUNUUyIsInByb2R1Y3RzIiwianNvbkZldGNoIiwiREVMRVRFX1BST0RVQ1RTIiwiQ1JFQVRFX1BST0RVQ1RTIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./state/reducer.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();